package stepDefinitions;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.concurrent.TimeUnit;

public class Hooks {
    //define before ad after annotation for your driver

    public static WebDriver driver = null;

    @Before
    public  void openBrowser()
    {

        System.setProperty("webdriver.chrome.driver","src/main/resources/chromedriver101.exe");

        driver = new ChromeDriver();

        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(12, TimeUnit.SECONDS);
        driver.navigate().to("https://demo.nopcommerce.com/");

    }

    @After
    public  void quitDriver()
    {
        driver.quit();
    }

}
