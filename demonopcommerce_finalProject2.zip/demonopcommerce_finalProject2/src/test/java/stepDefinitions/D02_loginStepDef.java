package stepDefinitions;

import Pages.P02_login;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

public class D02_loginStepDef {
    //WebDriver driver ;
    P02_login login=null;

    @When("user click on login tab")
    public void userclickonloginRTab()
    {
        //login.P02_login(driver);
        Hooks.driver.findElement(By.className("ico-login")).click();
    }

    @And("enter username and password")
    public void enternameandpassword() throws InterruptedException {
        Hooks.driver.findElement(By.name("Email")).sendKeys("user2@gmail.com");
        Hooks.driver.findElement(By.name("Password")).sendKeys("P@ssw0rd");
        Thread.sleep(2000);
    }
    @And("click on login button")
    public void clickonloginbutton() throws InterruptedException {
        Hooks.driver.findElement(By.cssSelector("button[class=\"button-1 login-button\"]")).click();
        Thread.sleep(5000);
    }
    SoftAssert soft;

    @Then("user in login mode")
public void userinloginmode() throws InterruptedException {
        soft= new SoftAssert();

        //String expectedurl="https://demo.nopcommerce.com/";
        String actualurl=Hooks.driver.getCurrentUrl();

        soft.assertEquals(actualurl,"https://demo.nopcommerce.com/");
        Thread.sleep(10000);

    soft.assertAll();
    }

    @Then("myaccount tab is displayed")
    public void myaccounttabisdisplayed() throws InterruptedException {

        soft = new SoftAssert();
        soft.assertTrue(Hooks.driver.findElement(By.className("ico-account")).isDisplayed());
        Thread.sleep(3000);
        soft.assertAll();


    }

    /*@And("^enter \"(.*)\" and \"(.*)\"$")
    public void valid_data(String userEmail, String password)

    {

        login.LoginSteps(userEmail,password);
    }*/

}
