package stepDefinitions;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.cucumber.java.en_old.Ac;
import io.cucumber.plugin.event.HookTestStep;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

public class D03_CurrenciesStepDef {
    @When("user can Select “Euro” from currency dropdown list")
    public void userselectEuro() throws InterruptedException {
        Hooks.driver.findElement(By.name("customerCurrency")).
                sendKeys("Euro");
Thread.sleep(3000);
    }

   @Then("currency is Euro")
    public void selectEuroCurrency() throws InterruptedException {

       Select selectCurrency = new Select(Hooks.driver.findElement(By.xpath("//*[@id=\"customerCurrency\"]")));
       selectCurrency.selectByValue("https://demo.nopcommerce.com/changecurrency/6?returnUrl=%2F");
       Thread.sleep(2000);
   }

}
