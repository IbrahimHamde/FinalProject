package stepDefinitions;

import Pages.P04_shoppingCart;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.By;
import org.testng.Assert;


public class D09_ShoppingCartStepDef {
    P04_shoppingCart shoppingCart= new P04_shoppingCart();
    int number;

    @When("user add product to shopping cart")
    public void addproducttoshoppingcart() throws InterruptedException {
        shoppingCart.shoppingcartBtns().get(2).click();
        Thread.sleep(3000);

    }
    @Then("shopping cart notification success is visible")
    public void shoppingcartnotifisuccessisvisible() throws InterruptedException {
        Assert.assertTrue(Hooks.driver.findElement(By.cssSelector("div[class=\"bar-notification-container\"]")).isDisplayed());
        Thread.sleep(3000);

    }



}
