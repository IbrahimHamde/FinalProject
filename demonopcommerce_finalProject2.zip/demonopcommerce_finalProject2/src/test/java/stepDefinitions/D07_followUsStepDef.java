package stepDefinitions;

import Pages.P03_homePage;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import javafx.scene.control.Tab;
import org.openqa.selenium.By;
import org.testng.Assert;
import sun.security.x509.OtherName;
import java.util.ArrayList;

public class D07_followUsStepDef {
    @When("click on facebook link")
    public void clickonfacebooklink() throws InterruptedException {
        Hooks.driver.findElement(By.className("facebook")).click();
        Thread.sleep(5000);
    }

   @Then("nopcommerce facebook page is opened in new tab")
    public void windowHandler() throws InterruptedException {
       ArrayList<String> Tabs = new ArrayList<>(Hooks.driver.getWindowHandles());
        Thread.sleep(2000);

        Hooks.driver.switchTo().window((String) Tabs.get(1));

        System.out.println(Hooks.driver.getCurrentUrl());
        Assert.assertEquals(Hooks.driver.getCurrentUrl(), "https://www.facebook.com/nopCommerce");

// that's because we need to only close tab 1
        Hooks.driver.close();

        Hooks.driver.switchTo().window((String) Tabs.get(0));
        System.out.println(Hooks.driver.getCurrentUrl());

// that's because we need to close the whole browser after finishing all the steps as we used to do before
        Hooks.driver.quit();

    }
    @When("cick on twitter link")
    public void clickontwitterlink() throws InterruptedException {
        Hooks.driver.findElement(By.className("twitter")).click();
        Thread.sleep(5000);
    }


        @Then("nopcommerce twitter page is opened in new tab")
        public void twitterpageisopenedinnewtab() throws InterruptedException {

            ArrayList<String> Tabs = new ArrayList<>(Hooks.driver.getWindowHandles());
            Thread.sleep(2000);

            Hooks.driver.switchTo().window((String) Tabs.get(1));

            System.out.println(Hooks.driver.getCurrentUrl());
            Assert.assertEquals(Hooks.driver.getCurrentUrl(), "https://twitter.com/nopCommerce");

// that's because we need to only close tab 1
            Hooks.driver.close();

            Hooks.driver.switchTo().window((String) Tabs.get(0));
            System.out.println(Hooks.driver.getCurrentUrl());

// that's because we need to close the whole browser after finishing all the steps as we used to do before
            Hooks.driver.quit();

    }
@When("click on rss link")
    public void clickonrsslink() throws InterruptedException {
    Hooks.driver.findElement(By.className("rss")).click();
    Thread.sleep(2000);
}
@Then("nopcommerce rss page is opened in new tab")
    public void rssPageIsOpened() throws InterruptedException {
    ArrayList<String> Tabs = new ArrayList<>(Hooks.driver.getWindowHandles());
    Thread.sleep(2000);

    Hooks.driver.switchTo().window((String) Tabs.get(1));

    System.out.println(Hooks.driver.getCurrentUrl());
    Assert.assertEquals(Hooks.driver.getCurrentUrl(), "https://demo.nopcommerce.com/new-online-store-is-open");

    Hooks.driver.close();

    Hooks.driver.switchTo().window((String) Tabs.get(0));
    System.out.println(Hooks.driver.getCurrentUrl());

    Hooks.driver.quit();

}

@When("click on youtube link")
    public void clickOnYoutubeLink() throws InterruptedException {
    Hooks.driver.findElement(By.className("youtube")).click();
    Thread.sleep(2000);

}

@Then("nopcommerce youtube is opened in new tab")
    public void Youtubepageisopened() throws InterruptedException {
    ArrayList<String> Tabs = new ArrayList<>(Hooks.driver.getWindowHandles());
    Thread.sleep(2000);

    Hooks.driver.switchTo().window((String) Tabs.get(1));

    System.out.println(Hooks.driver.getCurrentUrl());
    Assert.assertEquals(Hooks.driver.getCurrentUrl(), "https://www.youtube.com/user/nopCommerce");

    Hooks.driver.close();

    Hooks.driver.switchTo().window((String) Tabs.get(0));
    System.out.println(Hooks.driver.getCurrentUrl());

    Hooks.driver.quit();

}




}
