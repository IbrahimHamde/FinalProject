package stepDefinitions;

import Pages.P03_homePage;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.By;
import org.testng.Assert;

public class D06_homeSlidersStepDef {
    @When("user click on first slider")
    public void clickonslider()  {
        P03_homePage home = new P03_homePage();
        home.sliders("1").click();
    }
    @Then("page is changed to nokia Lumia 1020 page")
    public void checkPageisChanged() throws InterruptedException {
        Assert.assertTrue(Hooks.driver.getCurrentUrl().contains("https://demo.nopcommerce.com/nokia-lumia-1020"));
        Thread.sleep(3000);
    }

    @When("user click on second slider")
    public void clickonsecondslider()
    {
        P03_homePage home = new P03_homePage();
        home.sliders("2").click();
    }
    @Then("page is changed to iphone")
    public void checkPageischangedtoiphone()
    {
        Assert.assertTrue(Hooks.driver.getCurrentUrl().contains("https://demo.nopcommerce.com/page-not-found"));
    }


   /*@When("user click on Nokia Lumia 1020")
    public void clickonfirstslider() throws InterruptedException {
       Hooks.driver.findElement(By.className("nivo-caption")).click();

       Thread.sleep(5000);

    }
    @Then("user go to nokia Lumia 1020 page")
    public void navigatetoNokiaLumia1020Page()
    {
        String expectedResult="https://demo.nopcommerce.com/nokia-lumia-1020";
        String actualResult=Hooks.driver.getCurrentUrl();

    }*/
}
