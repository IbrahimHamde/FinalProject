package stepDefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

public class D04_searchStepDef {
    @When("click on search field in Home page")
    public void clickonsearchfield() throws InterruptedException {
        Hooks.driver.findElement(By.id("small-searchterms")).sendKeys("apple");
        Thread.sleep(3000);
    }

    @And("click on search button")
    public void clickonsearchbutton() throws InterruptedException {
        Hooks.driver.findElement(By.xpath("/html/body/div[6]/div[1]/div[2]/div[2]/form/button")).click();
        //Thread.sleep(2000);
    }
    @Then("the search is apprear")
    public void appearthesearch() {
        SoftAssert soft= new SoftAssert();
        soft.assertEquals(Hooks.driver.getCurrentUrl(),"https://demo.nopcommerce.com/search?q=apple","Search Assertion");

soft.assertAll();
    }
}
