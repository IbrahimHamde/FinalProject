package stepDefinitions;

import io.cucumber.java.bs.A;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.cucumber.java.en_lol.AN;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import java.awt.*;
import java.security.Key;
import java.security.PublicKey;


public class D01_registerStepDef {
    WebDriver driver =null;

    /*@When("user navigate to nopcommerce Website")
    public void user_navigates()
    {
        Hooks.driver.navigate().to("https://demo.nopcommerce.com/");
    }*/
@When("click on Register tab")
    public void userclickonRegisterTab()
{
       Hooks.driver.findElement(By.className("ico-register")).click();
}

@And ("click on Male option")
    public void userclickonMaleoption()  {
    Hooks.driver.findElement(By.className("male")).click();

}

@And("fill first Name")
    public void fillfirstname()  {
  Hooks.driver.findElement(By.name("FirstName")).sendKeys("Ibrahim");
}

    @And("Fill Last Name")
    public void fillsecondname() {
        Hooks.driver.findElement(By.name("LastName")).sendKeys("Hamdy");

    }
    @And ("Select DayofBirth")
    public void selectDayofBirth() {
        Hooks.driver.findElement(By.name("DateOfBirthDay")).sendKeys(Keys.NUMPAD3);
    }

    @And ("Select MonthofBirth")
    public void selectMonthofBirth() {
        Hooks.driver.findElement(By.name("DateOfBirthMonth")).sendKeys("July");

    }
    @And ("Select YearofBirth")
    public void selectYearofBirth() {
        Hooks.driver.findElement(By.name("DateOfBirthYear")).sendKeys("2000");

    }
    @And ("Enter Email")
    public void enterEmail() {
        Hooks.driver.findElement(By.name("Email")).sendKeys("user3@gmail.com");
    }

    @And("Enter companyName")
    public void entercompanyname() {
        Hooks.driver.findElement(By.id("Company")).sendKeys("AHBS");
    }

@And("Enter Password")
    public void enterpassword(){
    Hooks.driver.findElement(By.name("Password")).sendKeys("P@ssw0rd");

}

@And("Enter PasswordConfirm")
    public void confirmpassword()  {
        Hooks.driver.findElement(By.name("ConfirmPassword")).sendKeys("P@ssw0rd");

}

@And("click on Register Button")
    public void clickonregsterbutton()  {
        //Hooks.driver.findElement(By.id("register-button")).click();
    Hooks.driver.findElement(By.name("register-button")).click();
    //Hooks.driver.findElement(By.className("button-1 register-next-step-button")).click();

}
@Then("user could Register Successflly")
public void success_Register()  {
    String expectedResult="Your registration completed";
    String actualResult= Hooks.driver.findElement(By.className("result")).getText();

    Assert.assertTrue(actualResult.contains(expectedResult));
    Assert.assertEquals(actualResult,expectedResult);

    SoftAssert soft= new SoftAssert();
    System.out.println("First Asseration");
    soft.assertEquals(actualResult.contains(expectedResult),true,"First Assertion Equals: ");
    soft.assertTrue(actualResult.contains(expectedResult),"First Assertion True");
soft.assertAll();
/// second Assertion
    System.out.println("Second Asseration");
    String expectedcolor="rgba(76, 177, 124, 1)";
    String actualcolor= Hooks.driver.findElement(By.className("result")).getCssValue("color");
    Assert.assertTrue(actualcolor.contains(expectedcolor), "TrueColor");



}
}
