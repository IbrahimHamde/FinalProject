package stepDefinitions;

import Pages.P03_homePage;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.By;
import org.testng.Assert;
public class D08_wishlistStepDef {
P03_homePage home= new P03_homePage();
    int number;
    @When("user add product to wishlist")
    public  void wishlist() throws InterruptedException {
        //add product directly to wishlist
home.wishlistBtns().get(2).click();
Thread.sleep(3000);
    }
    @Then("wishlist notification success is visible")
    public void notification_success()
    {
        Assert.assertTrue(Hooks.driver.findElement(By.cssSelector("div[class=\"bar-notification success\"]")).isDisplayed());
        //div[class="bar-notification success"]
    }

    @Then("user get the number of wishlsit items after adding product")
    public void wishlist_items()
    {

      String text=  Hooks.driver.findElement(By.cssSelector("Span[class=\"wishlist-qty\"]")).getText();
        System.out.println(text);

       text =  text.replaceAll("[^0-9]",""); //remove ()
       number =  Integer.parseInt(text);

        Assert.assertTrue(number>0);
    }
@Then("number of wishlist items increased")
    public void items_increased()
{
    Assert.assertTrue(number>0);

}

}
