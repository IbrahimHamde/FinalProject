package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import stepDefinitions.Hooks;

import java.util.List;

public class P04_shoppingCart {
    /*public WebElement sliders(String num)
    {
        return Hooks.driver.findElement(By.cssSelector("button[class=\"button-2 product-box-add-to-cart-button\"]:nth-child("+num+")"));
    }*/
    public List<WebElement> shoppingcartBtns()
    {

        return Hooks.driver.findElements(By.cssSelector("button[class=\"button-2 product-box-add-to-cart-button\"]"));
    }
}
