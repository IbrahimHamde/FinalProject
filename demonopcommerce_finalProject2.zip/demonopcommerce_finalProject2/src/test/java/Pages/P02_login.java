package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import stepDefinitions.Hooks;

public class P02_login {

    WebDriver driver;

    public void P02_login(WebDriver driver)
    {
        this.driver=driver;
        PageFactory.initElements(driver,this);

    }


    @FindBy(name="Email")
    WebElement userEmailPF;

    public WebElement userEmailPOM()
    {
        By email= By.name("Email");
        WebElement userEmail= Hooks.driver.findElement(email);
        return userEmail;
    }
    public WebElement passwordPOM()
    {

        //WebElement passwordEle= driver.findElement(By.name("password"));
        return Hooks.driver.findElement(By.name("Password"));
    }
/*
    public By flashPOM()
    {
        return By.id("flash");
    }
    public By logoutPOM()
    {
        return By.cssSelector("a[href=\"/logout\"]");
    }
*/
    public  void LoginSteps(String userEmail, String password)

    {
        //Enter Username using POM
        //use page factory
        userEmailPF.clear();
        //---------------------------------
        //usernamePOM().clear();
        userEmailPOM().sendKeys(userEmail);
        //Enter Password using POM
        passwordPOM().sendKeys(password);


    }

}
